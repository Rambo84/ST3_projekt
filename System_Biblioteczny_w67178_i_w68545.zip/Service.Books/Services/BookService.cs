using Microsoft.EntityFrameworkCore;
using Service.Books.Entities;
using Service.Books.BookDb;
//using Service.Books.Resolver;
using Service.Books.Interfaces;
using Service.Books.Dtos;

namespace Service.Books.Services
{
    public class BookService: IBookService
    {
        private readonly BookDbContext _context;
        public BookService(BookDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<BookDto>> GetAll() {
            return await _context.Books.AsNoTracking().Select(b => (BookDto)b).ToListAsync();
        }
        
        public async Task<BookDto> GetByISBN(string isbn) {
            var book = await _context.Books.AsNoTracking().FirstOrDefaultAsync(x => x.ISBN == isbn);
            if (book == null) return null;
            return (BookDto)book;
        }

        public async Task Add(BookDto entity)
        {
            //var resolver = new BookResolver();
            /*foreach (var book in entity.innalista)
            {
                book.Name = await resolver.ResolveFor(book.BookExternalId);
            }*/
            _context.Set<Book>().Add((Book)entity);
            await _context.SaveChangesAsync();
        }

        public async Task Update(BookDto entity)
        { 
            _context.Set<Book>().Update((Book)entity);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(BookDto entity)
        { 
            var book = await GetByISBN(entity.ISBN);
            if (book != null)
            {
                _context.Set<Book>().Remove((Book)book);
                await _context.SaveChangesAsync();
            }
        }
    }
}
