using Service.Books.Services;
using Service.Books.BookDb;

namespace Service.Books.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddBookServices(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddDbContext<BookDbContext, BookDbContext>();
            serviceCollection.AddTransient<BookService>();
            return serviceCollection;
        }
    }
}
