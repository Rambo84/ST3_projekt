using Microsoft.EntityFrameworkCore;
using Service.Books.Entities;

namespace Service.Books.BookDb
{
    public class BookDbContext : DbContext
    {
        private IConfiguration _configuration { get; }

        public DbSet<Book> Books { get; set; }

        public BookDbContext(IConfiguration configuration) : base()
        {
            _configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(@"server=(localdb)\MSSQLLocalDB;database=STUDENT-dev;trusted_connection=true;",
                // options.UseSqlSever("",
                x => x.MigrationsHistoryTable("__EFMigrationsHistory", "projekt"));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
