/*using Newtonsoft.Json;
using System.Net.Http.Headers;
using Service.Books.Dtos;
using Service.Books.Entities;

namespace Service.Books.Resolver
{
    public class BookResolver
    {
        public async Task<string> ResolveFor(Book book)
        {
            return await ResolveFromExternalDirectory(book);
        }
        private async Task<string?> ResolveFromExternalDirectory(Book book)
        {
            string apiUrl = "http://localhost:5126/";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(apiUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                //client.DefaultRequestHeaders.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await client.GetAsync("books");
                string responseData = await response.Content.ReadAsStringAsync();
                List<BookDto> books = JsonConvert.DeserializeObject<List<BookDto>>(responseData);
                return books.FirstOrDefault(x => x.ISBN == book.ISBN).Title;
            }
        }
    }
}*/
