using Service.Books.Entities;
using Service.Books.Dtos;

namespace Service.Books.Interfaces{
    public interface IBookService{
        Task<IEnumerable<BookDto>> GetAll();
        Task<BookDto> GetByISBN(string isbn);
        Task Add(BookDto book);
        Task Update(BookDto book);
        Task Delete(BookDto book);
    }
}