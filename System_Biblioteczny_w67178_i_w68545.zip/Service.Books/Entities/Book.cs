using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Service.Books.Dtos;

namespace Service.Books.Entities
{
    [Table("Books", Schema = "projekt")]
    public class Book
    {
        [Key]
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Author { get; set; }
        public string? ISBN { get; set; }
        public DateTime PublishedDate { get; set; }
        public bool IsAvailable { get; set; }

        public static explicit operator Book(BookDto dto){
            return new Book
            {
                Id = dto.Id,
                Title = dto.Title,
                Author = dto.Author,
                ISBN = dto.ISBN,
                PublishedDate = dto.PublishedDate,
                IsAvailable = dto.IsAvailable
            };
        }
    }
}
