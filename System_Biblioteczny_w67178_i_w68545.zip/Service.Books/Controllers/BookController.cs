using Microsoft.AspNetCore.Mvc;
using Service.Books.Services;
using Service.Books.Entities;
using Service.Books.Dtos;

namespace Service.Books.Controllers
{
    public class BookController : ControllerBase
    {
        private readonly BookService _bookService;
        public BookController (BookService bookService)
        {
            _bookService = bookService;
        }
        [HttpGet("books")]
        public async Task<IEnumerable<BookDto>> Read() => await _bookService.GetAll();
        [HttpGet("books/{isbn}")]
        public async Task<IActionResult> ReadByISBN(string isbn)
        {
            var bookDto = await _bookService.GetByISBN(isbn);
            if (bookDto == null) return NotFound();
            return Ok(bookDto);
        }
        [HttpPost("book")]
        public async Task<IActionResult> Create([FromBody] BookDto dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _bookService.Add(dto);
            return Ok();
        }
        /*public IActionResult Index()
        {
            return View();
        }*/
    }
}
