using System.ComponentModel.DataAnnotations;
using Service.Books.Entities;
//using Service.Books.ValidationAttributes;

namespace Service.Books.Dtos
{
    public class BookDto
    {
        [Key]
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Author { get; set; }
        public string? ISBN { get; set; }
        public DateTime PublishedDate { get; set; }
        public bool IsAvailable { get; set; }

        public static explicit operator BookDto(Book book){
            return new BookDto
            {
                Id = book.Id,
                Title = book.Title,
                Author = book.Author,
                ISBN = book.ISBN,
                PublishedDate = book.PublishedDate,
                IsAvailable = book.IsAvailable
            };
        }
    }
}
