using Service.Books.Extensions;
using Service.Borrow.Extensions;
using Service.Loyalty.Extensions;
using Service.Reader.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddBookServices();
builder.Services.AddBorrowServices();
builder.Services.AddReaderServices();
builder.Services.AddLoyaltyServices();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

/*using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;

    var bookContext = services.GetRequiredService<Service.Books.BookDb.BookDbContext>();
    Service.Books.BookDb.BookDbInitializer.Seed(bookContext);
    
    var borrowContext = services.GetRequiredService<Service.Borrow.BorrowDb.BorrowDbContext>();
    Service.Borrow.BorrowDb.BorrowDbInitializer.Seed(borrowContext);
    
    var loyaltyContext = services.GetRequiredService<Service.Loyalty.LoyaltyDb.LoyaltyDbContext>();
    Service.Loyalty.LoyaltyDb.LoyaltyDbInitializer.Seed(loyaltyContext);
    
    var readerContext = services.GetRequiredService<Service.Reader.ReaderDb.ReaderDbContext>();
    Service.Reader.ReaderDb.ReaderDbInitializer.Seed(readerContext);
}*/

app.MapControllers();
app.Run();

record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
